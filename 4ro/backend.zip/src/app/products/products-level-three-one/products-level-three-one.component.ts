import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-products-level-three-one',
  templateUrl: './products-level-three-one.component.html',
  styleUrls: ['./products-level-three-one.component.scss']
})
export class ProductsLevelThreeOneComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
