

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
    <?php if(auth()->guard()->check()): ?>
    

    <span>Welcome <?php echo e(Auth::user()->username); ?></span>
    <a href="/logout"><button>Logout</button></a>
        
    <?php else: ?>
        
    
    
    <a href="/register"><button>Register</button></a>
    <a href="/login"><button>Login</button></a>
    
    
    
    <?php endif; ?>
    




    <?php $__currentLoopData = $announcements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $announcement): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
   
    
    <h1><?php echo e(optional($announcement->user)->username ?? 'N/A'); ?> </h1>
    <h1><?php echo e($announcement->user_id); ?></h1>
        <h1><?php echo e($announcement->announcement_title); ?></h1>
        <p><?php echo e($announcement->announcement_content); ?></p>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php if(auth()->guard()->check()): ?>
    <form method="POST" action="/announcements">
    <?php echo csrf_field(); ?>

    
    <input type="text" name="announcement_title" placeholder="Title">
    <?php $__errorArgs = ['announcement_title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <div class="alert alert-danger">Not valid</div>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    <input type="text" name="announcement_content" placeholder="Content">
    <?php $__errorArgs = ['announcement_content'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <div class="alert alert-danger">Not valid</div>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    <button type="submit">Submit</button>
    </form>
<?php endif; ?>
</body>
</html><?php /**PATH D:\codeMavericks-Ussayed\Back_end\resources\views/index.blade.php ENDPATH**/ ?>