import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-products-level-three-two',
  templateUrl: './products-level-three-two.component.html',
  styleUrls: ['./products-level-three-two.component.scss']
})
export class ProductsLevelThreeTwoComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
