export const languages = [
  {
    Language: 'English',
    flag: 'us'
  },
  {
    Language: 'Hungarian',
    flag: 'hungary'
  },
  {
    Language: 'Arabic',
    flag: 'arabic'
  },

];
